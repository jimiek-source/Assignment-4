```python
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

```


```python
import zipfile
import os

# Path to the zip file
zip_file_path = 'path_to_your_dataset.zip'
output_folder = 'Netflix_shows_movies'

# Unzipping the file
with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
    zip_ref.extractall(output_folder)

```


```python
df.info()
```


```python
df =pd.DataFrame(df)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>show_id</th>
      <th>type</th>
      <th>title</th>
      <th>director</th>
      <th>cast</th>
      <th>country</th>
      <th>date_added</th>
      <th>release_year</th>
      <th>rating</th>
      <th>duration</th>
      <th>listed_in</th>
      <th>description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>81145628</td>
      <td>Movie</td>
      <td>Norm of the North: King Sized Adventure</td>
      <td>Richard Finn, Tim Maltby</td>
      <td>Alan Marriott, Andrew Toth, Brian Dobson, Cole...</td>
      <td>United States, India, South Korea, China</td>
      <td>September 9, 2019</td>
      <td>2019</td>
      <td>TV-PG</td>
      <td>90 min</td>
      <td>Children &amp; Family Movies, Comedies</td>
      <td>Before planning an awesome wedding for his gra...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>80117401</td>
      <td>Movie</td>
      <td>Jandino: Whatever it Takes</td>
      <td>NaN</td>
      <td>Jandino Asporaat</td>
      <td>United Kingdom</td>
      <td>September 9, 2016</td>
      <td>2016</td>
      <td>TV-MA</td>
      <td>94 min</td>
      <td>Stand-Up Comedy</td>
      <td>Jandino Asporaat riffs on the challenges of ra...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>70234439</td>
      <td>TV Show</td>
      <td>Transformers Prime</td>
      <td>NaN</td>
      <td>Peter Cullen, Sumalee Montano, Frank Welker, J...</td>
      <td>United States</td>
      <td>September 8, 2018</td>
      <td>2013</td>
      <td>TV-Y7-FV</td>
      <td>1 Season</td>
      <td>Kids' TV</td>
      <td>With the help of three human allies, the Autob...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>80058654</td>
      <td>TV Show</td>
      <td>Transformers: Robots in Disguise</td>
      <td>NaN</td>
      <td>Will Friedle, Darren Criss, Constance Zimmer, ...</td>
      <td>United States</td>
      <td>September 8, 2018</td>
      <td>2016</td>
      <td>TV-Y7</td>
      <td>1 Season</td>
      <td>Kids' TV</td>
      <td>When a prison ship crash unleashes hundreds of...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>80125979</td>
      <td>Movie</td>
      <td>#realityhigh</td>
      <td>Fernando Lebrija</td>
      <td>Nesta Cooper, Kate Walsh, John Michael Higgins...</td>
      <td>United States</td>
      <td>September 8, 2017</td>
      <td>2017</td>
      <td>TV-14</td>
      <td>99 min</td>
      <td>Comedies</td>
      <td>When nerdy high schooler Dani finally attracts...</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Handling and dropping missing values.

df_cleaned = df.dropna()
```


```python
# Read column and check their names to avoid errors during out work.

df.drop(columns="director", inplace = True)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>show_id</th>
      <th>type</th>
      <th>title</th>
      <th>cast</th>
      <th>country</th>
      <th>date_added</th>
      <th>release_year</th>
      <th>rating</th>
      <th>duration</th>
      <th>listed_in</th>
      <th>description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>81145628</td>
      <td>Movie</td>
      <td>Norm of the North: King Sized Adventure</td>
      <td>Alan Marriott, Andrew Toth, Brian Dobson, Cole...</td>
      <td>United States, India, South Korea, China</td>
      <td>September 9, 2019</td>
      <td>2019</td>
      <td>TV-PG</td>
      <td>90 min</td>
      <td>Children &amp; Family Movies, Comedies</td>
      <td>Before planning an awesome wedding for his gra...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>80117401</td>
      <td>Movie</td>
      <td>Jandino: Whatever it Takes</td>
      <td>Jandino Asporaat</td>
      <td>United Kingdom</td>
      <td>September 9, 2016</td>
      <td>2016</td>
      <td>TV-MA</td>
      <td>94 min</td>
      <td>Stand-Up Comedy</td>
      <td>Jandino Asporaat riffs on the challenges of ra...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>70234439</td>
      <td>TV Show</td>
      <td>Transformers Prime</td>
      <td>Peter Cullen, Sumalee Montano, Frank Welker, J...</td>
      <td>United States</td>
      <td>September 8, 2018</td>
      <td>2013</td>
      <td>TV-Y7-FV</td>
      <td>1 Season</td>
      <td>Kids' TV</td>
      <td>With the help of three human allies, the Autob...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>80058654</td>
      <td>TV Show</td>
      <td>Transformers: Robots in Disguise</td>
      <td>Will Friedle, Darren Criss, Constance Zimmer, ...</td>
      <td>United States</td>
      <td>September 8, 2018</td>
      <td>2016</td>
      <td>TV-Y7</td>
      <td>1 Season</td>
      <td>Kids' TV</td>
      <td>When a prison ship crash unleashes hundreds of...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>80125979</td>
      <td>Movie</td>
      <td>#realityhigh</td>
      <td>Nesta Cooper, Kate Walsh, John Michael Higgins...</td>
      <td>United States</td>
      <td>September 8, 2017</td>
      <td>2017</td>
      <td>TV-14</td>
      <td>99 min</td>
      <td>Comedies</td>
      <td>When nerdy high schooler Dani finally attracts...</td>
    </tr>
  </tbody>
</table>
</div>




```python
# checking for missing values

df.isna().sum()
```




    show_id           0
    type              0
    title             0
    cast            570
    country         476
    date_added       11
    release_year      0
    rating           10
    duration          0
    listed_in         0
    description       0
    dtype: int64




```python
df =df.dropna(subset =["cast"])
```


```python
df =df.dropna(subset =["country"])
```


```python
df =df.dropna(subset =["date_added"])
```


```python
df =df.dropna(subset =["rating"])
```


```python
df.isna().sum()
```




    show_id         0
    type            0
    title           0
    cast            0
    country         0
    date_added      0
    release_year    0
    rating          0
    duration        0
    listed_in       0
    description     0
    dtype: int64




```python
df.duplicated("show_id").sum()
```




    0




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>show_id</th>
      <th>release_year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>5.256000e+03</td>
      <td>5256.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>7.614151e+07</td>
      <td>2013.005708</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.165199e+07</td>
      <td>8.787326</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2.477470e+05</td>
      <td>1942.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>8.000319e+07</td>
      <td>2012.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>8.015263e+07</td>
      <td>2016.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>8.023829e+07</td>
      <td>2018.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>8.123573e+07</td>
      <td>2020.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
# Visualization
```


```python
Rating Distribution:
```


```python
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
plt.figure(figsize=(8,6))
sns.histplot(df['rating'], kde=True, bins=20, color='blue')
plt.title('Rating Distribution')
plt.xlabel('Rating')
plt.ylabel('Frequency')
plt.show()
```

    /opt/conda/envs/anaconda-2024.02-py310/lib/python3.10/site-packages/seaborn/_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):



    
![png](output_18_1.png)
    



```python
plt.figure(figsize=(10, 6))
sns.barplot(x=genre_counts.index, y=genre_counts.values, palette='viridis')
plt.title('Top 10 Most Watched Genres')
plt.xlabel('Genre')
plt.ylabel('Number of Shows/Movies')
plt.xticks(rotation=45)
plt.show()
```


```python
library(ggplot2)
genre_counts <- read.csv('genre_counts.csv')

# Plot the top genres in R
ggplot(genre_counts, aes(x=reorder(genre_counts$genre, -genre_counts$Freq), y=genre_counts$Freq)) +
    geom_bar(stat='identity', fill='blue') +
    theme(axis.text.x = element_text(angle=45, hjust=1)) +
    labs(title='Top 10 Most Watched Genres', x='Genre', y='Number of Shows/Movies')
```


```python

```
